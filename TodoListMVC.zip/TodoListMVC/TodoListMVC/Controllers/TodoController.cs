﻿using Microsoft.AspNetCore.Mvc;
using TodoListMVC.Models;

namespace TodoListMVC.Controllers
{
    public class TodoController : Controller
    {
        private static List<TodoItem> _todos = new List<TodoItem>()
        {
            new TodoItem{ Id = 1, Name = "Đi chợ", IsCompleted = true },
            new TodoItem{ Id = 2, Name = "Chơi thể thao", IsCompleted = false },
            new TodoItem{ Id = 3, Name = "Chơi game", IsCompleted = false },
            new TodoItem{ Id = 4, Name = "Học bài", IsCompleted = false }
        };

        [HttpPost]
        public IActionResult ToggleStatus(int id)
        {
            var todo = _todos.FirstOrDefault(x => x.Id == id);
            if (todo != null)
            {
                todo.IsCompleted = !todo.IsCompleted;
            }
            return RedirectToAction("Index");
        }


        public IActionResult Index()
        {
            return View(_todos);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(TodoItem item)
        {
            item.Id = _todos.Max(x => x.Id) + 1;
            _todos.Add(item);
            return RedirectToAction("Thanks");
        }

        public IActionResult Edit(int id)
        {
            var todo = _todos.FirstOrDefault(x => x.Id == id);
            return View(todo);
        }

        [HttpPost]
        public IActionResult Edit(TodoItem item)
        {
            var todo = _todos.FirstOrDefault(x => x.Id == item.Id);
            if (todo != null)
            {
                todo.Name = item.Name;
                todo.IsCompleted = item.IsCompleted;
            }
            return RedirectToAction("Index");
        }

        public IActionResult Details(int id)
        {
            var todo = _todos.FirstOrDefault(x => x.Id == id);
            return View(todo);
        }

        public IActionResult Delete(int id)
        {
            var todo = _todos.FirstOrDefault(x => x.Id == id);
            if (todo != null) _todos.Remove(todo);
            return RedirectToAction("Index");
        }

        public IActionResult Thanks()
        {
            return View();
        }
    }
}
